// import App from "./D:DAIICT_tic_tac_toe/tic-tac-toe/src/App";
import { Search } from "./components/search";
import ChatInterface from "./components/chat";

function Chatbot() {
    return(
      <ChatInterface />
    )
}

export default Chatbot;