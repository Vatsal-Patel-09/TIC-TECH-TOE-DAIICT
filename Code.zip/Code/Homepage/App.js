import './App.css';
import { Footer } from './footer';
import { Hero } from './hero';
import { Navbar } from './navbar';
import { Contact } from './contact';
import './chatbot'

function App() {
  return (
    <div>
      <Navbar />
      <Hero />
      <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
      <Contact />
      <br/><br/><br/>
      <Footer />

    </div>
    
  );
}

export default App;
