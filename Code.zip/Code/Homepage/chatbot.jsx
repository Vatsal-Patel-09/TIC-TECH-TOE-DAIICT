import App from "./App";
import { Search } from "./components/search";

function Chatbot() {
    return(
        <Search />
    )
}